package com.mycompany.e.commercemanagementsystem;

import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.logging.Level;
import java.util.logging.Logger;

abstract class Product{
    //attributes
    protected String productName;
    protected int productId,price,quantity;
    
    //methods
    abstract void addProduct();
    abstract void removeProduct();
    abstract int getQuantity();
    abstract void setQuantity(int quantity);
    abstract void printDetails();
    abstract void addProductInFile();
    abstract double getPrice();
    
    
    public void printUpdatedArrayInFile(){             //for printing the updated details in files 
         
         Book.getBookList();
         
        try {
            FileWriter fw = new FileWriter("allProducts.txt");
            //printing laptop details 
            for(int i = 0;i<Laptop.getLaptopList().size();i++){
                fw.write("Laptop Brand : "+Laptop.getLaptopList().get(i).getProductName() + "\n" +
                           "Laptop Model  : "+Laptop.getLaptopList().get(i).getModel()+ "\n" + 
                           "Laptop Product Id : "+Laptop.getLaptopList().get(i).getProductId()+ "\n" + 
                           "Laptop Price : "+Laptop.getLaptopList().get(i).getPrice()+"\n"+
                           "Laptops Quantity : "+Laptop.getLaptopList().get(i).getQuantity()+"\n"+
                           "Laptop Processor : "+Laptop.getLaptopList().get(i).getProcessor()+"\n"+
                            "Operating System : "+Laptop.getLaptopList().get(i).getOperatingSystem()+ "\n"+
                            "Warranty : "+Laptop.getLaptopList().get(i).getWarranty()+ "\n"+
                            "RAM : "+Laptop.getLaptopList().get(i).getRAM()+"\n"+
                            "Storage : "+Laptop.getLaptopList().get(i).getStorage()+"\n"+
                            "Screen Size : "+Laptop.getLaptopList().get(i).getScreenSize());             
            }
            //printing Books details 
            for(int i = 0;i<Book.getBookList().size();i++){
                fw.write("Book Title : "+Book.getBookList().get(i).getProductName() + "\n" +
                           "Book Author  : "+Book.getBookList().get(i).getAuthor()+ "\n" + 
                           "Book Id : "+Book.getBookList().get(i).getProductId()+ "\n" + 
                           "Book Price : "+Book.getBookList().get(i).getPrice()+"\n"+
                           "Books Quantity : "+Book.getBookList().get(i).getQuantity()+"\n"+
                           "Book ISBN : "+Book.getBookList().get(i).getISBN()+"\n"+
                            "Publication Date : "+Book.getBookList().get(i).getPublicationDate()+ "\n"+
                            "Book Genre : "+Book.getBookList().get(i).getGenre()+ "\n"+
                            "Book Description : "+Book.getBookList().get(i).getDescription()+"\n"+
                            "Book Edition : "+Book.getBookList().get(i).getEdition()+"\n"+
                            "Book Page Count : "+Book.getBookList().get(i).getPageCount()); 
            }
        } catch (IOException ex) {
            Logger.getLogger(Laptop.class.getName()).log(Level.SEVERE, null, ex);
        }
         
     }
     public void productAddTime(){    //to add the time of product being added in file for track

        //saving the time of product being added in a file
        LocalDateTime currentDateTime = LocalDateTime.now();
        
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        String formattedDateTime = currentDateTime.format(formatter);
        
        FileWriter outStream = null;
        try{
              outStream = new FileWriter("productManager",true); 
             outStream.write("Product Name : "+this.productName+"\nProduct ID : "+this.productId+"\n"
                             +"was added in inventory at "+formattedDateTime+"\n");
             outStream.close();
        }
        catch(FileNotFoundException e){
             System.out.println(e);
        }
        catch(IOException e){
            System.out.println(e);
        }
    }
      public void productRemoveTime(){    //to add the time of product being removed from file for track

        //saving the time of product being added in a file
        LocalDateTime currentDateTime = LocalDateTime.now();
        
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        String formattedDateTime = currentDateTime.format(formatter);
        
        FileWriter outStream = null;
        try{
              outStream = new FileWriter("productManager",true); 
             outStream.write("Product Name : "+this.productName+"\n Product ID : "+this.productId+"\n"
                             +"was removed from inventory at "+formattedDateTime+"\n");
             outStream.close();
        }
        catch(FileNotFoundException e){
             System.out.println(e);
        }
        catch(IOException e){
            System.out.println(e);
        }
    }
   
    //constructors

    public Product() {
    }

    public Product(String productName, int productId, int price, int quantity) {
        this.productName = productName;
        this.productId = productId;
        this.price = price;
        this.quantity = quantity;
    }
    
    
}
