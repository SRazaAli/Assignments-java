
package com.mycompany.e.commercemanagementsystem;

import java.util.Scanner;

public class AdminLogin extends Login{
    Scanner sc = new Scanner(System.in);
 
    //Constructor 
    public AdminLogin(){
        
    }
    
    //getters
    public String getUserName() {
        return userName;
    }

    public String getPassword() {
        return password;
    }
    
    //setters   
    public void setUserName(String userName){
        this.userName = userName;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    //methods
    @Override
    public void login() {
        System.out.println("========= Admin Login =========");
        System.out.print("Enter the User Name of Admin : ");
        sc.nextLine();
        System.out.print("Enter the password of Admin : ");
        sc.nextLine();
        if(userName == "admin" && password == "admin123")
            System.out.println("Admin has been succesfullu logged in ...");
        else if(userName == "admin "&& password != "admin123")
            System.out.println("Incorrect Password...");
        else if(userName != "admin "&& password == "admin123")
            System.out.println("Incorrect Username...");
        else
            System.out.println("Incorrect Credentials...");
    }
    
    @Override
    public void changePassword(){
        System.out.println("========= Change Password =========");
        System.out.print("Enter your previous Password : ");
        sc.nextLine();
        String previousPassword  = sc.nextLine();
        System.out.print("Enter your new Password : ");
        String newPassword = sc.nextLine();
        
        if(newPassword != previousPassword)
            this.password = newPassword;
        else if(previousPassword == newPassword)
            System.out.println("New Password can not be same as your last password");      
    }
    
    @Override
    public void printUserDetails(){
        System.out.println("========= Admin Credentials =========");
        System.out.println("User name : "+userName + "\n" +
                            "Password : "+password);
    }
}
