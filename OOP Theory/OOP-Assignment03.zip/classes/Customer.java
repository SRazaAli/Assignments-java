
package com.mycompany.e.commercemanagementsystem;

import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Scanner;

public class Customer extends Login{
    //attributes 
    private String mobileNo,email,shippingAddress;
    private int postCode;
    private ArrayList<Customer> customerList = new ArrayList<Customer>();
    Scanner sc = new Scanner(System.in);
    //Constructor

    public Customer() {
    }

   
    
    //getters

    public String getEmail() {
        return email;
    }

    public String getMobileNo() {
        return mobileNo;
    }

    public String getPassword() {
        return password;
    }

    public int getPostCode() {
        return postCode;
    }

    public String getShippingAddress() {
        return shippingAddress;
    }

    public String getUserName() {
        return userName;
    }

    public ArrayList<Customer> getCustomerList() {
        return customerList;
    }

    
    
    //setters
    public void setEmail(String email) {
        this.email = email;
    }

    public void setMobileNo(String mobileNo) {
        this.mobileNo = mobileNo;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public void setPostCode(int postCode) {
        this.postCode = postCode;
    }

    public void setShippingAddress(String shippingAddress) {
        this.shippingAddress = shippingAddress;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }
    //methods

    public void register(){
        System.out.println("========= User Registration =========");
        System.out.print("Enter your User Name : ");
        this.userName = sc.nextLine();
        System.out.print("Enter your Password : ");
        this.password =sc.nextLine();
        System.out.print("Enter your Mobile no : ");
        this.mobileNo = sc.nextLine();
        System.out.print("Enter your Shipping Address : ");
        this.shippingAddress = sc.nextLine();
        System.out.print("Enter your Post Code : ");
        this.postCode = sc.nextInt();
        customerList.add(this);
        System.out.println("Your Registration was successful :) ");
        
        //printing registration time in file
         LocalDateTime currentDateTime = LocalDateTime.now();
        
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        String formattedDateTime = currentDateTime.format(formatter);
        
        FileWriter outStream = null;
        try{
              outStream = new FileWriter("customerManager",true); 
             outStream.write("Customer Name : "+this.getUserName()+"\nCustomer ID : "+this.getPassword()+"\n"
                             +"was registered  at "+formattedDateTime+"\n");
             outStream.close();
        }
        catch(FileNotFoundException e){
             System.out.println(e);
        }
        catch(IOException e){
            System.out.println(e);
        }
    }
    public void login(){
        System.out.println("========= User Login =========");
        System.out.print("Enter your User Name : ");
        sc.nextLine();
        this.userName = sc.nextLine();
        System.out.print("Enter your Password : ");
        this.password =sc.nextLine();
        
        boolean isLoggedIn = false;
        for(int i = 0;i<customerList.size();i++){
            if(this.userName == customerList.get(i).getUserName() && this.password == customerList.get(i).getPassword()){
                isLoggedIn = true;
            }
        }
        String message =  isLoggedIn==true ? "User has been successfully Logged In ...\n":"User Doesn't exist\n";
        System.out.print(message);
           LocalDateTime currentDateTime = LocalDateTime.now();
        
           
           //printing the login time in file
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        String formattedDateTime = currentDateTime.format(formatter);
        
        FileWriter outStream = null;
        try{
              outStream = new FileWriter("customerManager",true); 
             outStream.write("Customer Name : "+this.getUserName()+"\nCustomer ID : "+this.getPassword()+"\n"
                             +"logged in at "+formattedDateTime+"\n");
             outStream.close();
        }
        catch(FileNotFoundException e){
             System.out.println(e);
        }
        catch(IOException e){
            System.out.println(e);
        }
        
    }
    public void changePassword(){
        System.out.println("========= Change Password =========");
        System.out.print("Enter your previous Password : ");
        sc.nextLine();
        String previousPassword  = sc.nextLine();
        System.out.print("Enter your new Password : ");
        String newPassword = sc.nextLine();
        
        if(newPassword != previousPassword)
            this.password = newPassword;
        else if(previousPassword == newPassword)
            System.out.println("Password can not be same as your last password");      
    }
    public void printUserDetails(){
        System.out.println("========= User Info =========");
        System.out.print("User name : "+userName + "\n" +
                            "Password : "+password + "\n"+
                            "Mobile no : "+mobileNo + "\n"+
                            "Shipping Address : "+shippingAddress + "\n"+
                            "Post Code : "+postCode);
//        for(int i = 0;i<customerList.size();i++){
//            System.out.print(customerList.get(i).getUserName()+" "+customerList.get(i).getPassword());
//        }
    }   
}
