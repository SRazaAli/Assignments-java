package com.mycompany.e.commercemanagementsystem;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;


public class AdminControls implements Adminable{
    Customer customerObj;
    Scanner sc = new Scanner(System.in);
    
    @Override
    public void viewLoginHistroy(){
                    System.out.println("========= View Login History =========");

         String filePath = "loginManager.txt"; 
         try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            String line;

            // Read and print the enitre file
            while ((line = br.readLine()) != null) {
                System.out.println(line);
            }
        } catch (IOException e) {
            System.out.println("Error reading the file: " + e.getMessage());
        }
    }
    @Override
    public void viewInventory(){
                        System.out.println("========= View Inventory =========");

         String filePath = "allProducts.txt"; 
         try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            String line;

            // Read and print the enitre file
            while ((line = br.readLine()) != null) {
                System.out.println(line);
            }
        } catch (IOException e) {
            System.out.println("Error reading the file: " + e.getMessage());
        }
    }
    
    @Override
      public void viewOrderHistory(){
                        System.out.println("========= View Order History =========");

         String filePath = "orderManager.txt"; 
         try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            String line;

            // Read and print the enitre file
            while ((line = br.readLine()) != null) {
                System.out.println(line);
            }
        } catch (IOException e) {
            System.out.println("Error reading the file: " + e.getMessage());
        }
    }
    @Override
    public void deleteCustomer(){
                System.out.println("========= Delete Customer =========");
                System.out.print("Enter the username of the customer : ");
                String customerName = sc.nextLine();
                System.out.print("Enter the password of the customer : ");
                String customerPassword = sc.nextLine();
                
                //searching for customer
                boolean customerExists = false;
                for(int i = 0;i<customerObj.getCustomerList().size();i++){
                    if(customerObj.getCustomerList().get(i).getUserName() == customerName && customerObj.getCustomerList().get(i).getPassword() == customerPassword){
                       customerExists = true;
                        customerObj.getCustomerList().remove(customerObj.getCustomerList().get(i));
                        break;
                    }
                }
                if(customerExists)
                   System.out.println("Customer has been successfully deleted from the system...");
                else
                    System.out.println("There was an error deleting the cutsomer...");
                
                 LocalDateTime currentDateTime = LocalDateTime.now();
                 
        //printing the customer delete time in file....
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        String formattedDateTime = currentDateTime.format(formatter);
        
        FileWriter outStream = null;
        try{
              outStream = new FileWriter("customerManager",true); 
             outStream.write("Customer Name : "+customerName+"\nCustomer Password : "+customerPassword+"\n"
                             +"was deleted from the system at "+formattedDateTime+"\n");
             outStream.close();
        }
        catch(FileNotFoundException e){
             System.out.println(e);
        }
        catch(IOException e){
            System.out.println(e);
        }
                
    }
}

