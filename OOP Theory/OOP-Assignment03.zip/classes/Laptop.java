package com.mycompany.e.commercemanagementsystem;

import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

public class Laptop extends Product{
    private String model,processor,operatingSystem,warranty;
    private int RAM,storage,screenSize;
    Scanner sc = new Scanner(System.in);
    private static ArrayList<Laptop> laptopList = new ArrayList<Laptop>();
    
    //constructor

    public Laptop() {
    }

    public Laptop(String productName,int productId,int price,int quantity,String model, String processor, String operatingSystem, String warranty, int RAM, int storage, int screenSize) {
        super(productName,productId,price,quantity);
        this.model = model;
        this.processor = processor;
        this.operatingSystem = operatingSystem;
        this.warranty = warranty;
        this.RAM = RAM;
        this.storage = storage;
        this.screenSize = screenSize;
    }
    
   
    //getters 

    public String getModel() {
        return model;
    }

    public String getOperatingSystem() {
        return operatingSystem;
    }

    @Override
    public double getPrice() {
        return price;
    }

    public String getProcessor() {
        return processor;
    }

    public int getProductId() {
        return productId;
    }

    public String getProductName() {
        return productName;
    }

    @Override
    public int getQuantity() {
        return quantity;
    }

    public int getRAM() {
        return RAM;
    }

    public int getScreenSize() {
        return screenSize;
    }

    public int getStorage() {
        return storage;
    }

    public String getWarranty() {
        return warranty;
    }

    public static ArrayList<Laptop> getLaptopList() {
        return laptopList;
    }
    
    //setters 

    public void setModel(String model) {
        this.model = model;
    }

    public void setOperatingSystem(String operatingSystem) {
        this.operatingSystem = operatingSystem;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public void setProcessor(String processor) {
        this.processor = processor;
    }

    public void setProductId(int productId) {
        this.productId = productId;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public void setRAM(int RAM) {
        this.RAM = RAM;
    }

    public void setScreenSize(int screenSize) {
        this.screenSize = screenSize;
    }

    public void setStorage(int storage) {
        this.storage = storage;
    }

    public void setWarranty(String Warranty) {
        this.warranty = Warranty;
    }
    
    //methods
     public void addProduct(){
        System.out.println("========= Add Product =========");
        System.out.print("Enter Laptop Brand : ");
        productName = sc.nextLine();
        System.out.print("Enter Model of the Laptop : ");
        model = sc.nextLine();
        System.out.print("Enter Product ID of Laptop : ");
        productId = sc.nextInt();
        System.out.print("Enter Price of the Laptop  : ");
        price = sc.nextInt();
        System.out.print("Enter Quantity of Stock : ");
        quantity = sc.nextInt();
        System.out.print("Enter Processor of Laptop : ");
        sc.nextLine();
        processor = sc.nextLine();
        System.out.print("Enter Operating System of Laptop : ");
        operatingSystem = sc.nextLine();
        System.out.print("Enter Warranty of Laptop : ");
        warranty = sc.nextLine();
        System.out.print("Enter RAM (in GBs) : ");
        RAM = sc.nextInt();
        System.out.print("Enter Storage (in GBs) : ");
        storage = sc.nextInt();
        System.out.print("Enter Screen Size (in Inches) : ");
        screenSize = sc.nextInt();
        laptopList.add(this);
        
        System.out.println("Laptop has been added successfully in inventory...");
    }
     
     
     @Override
      public void addProductInFile(){
        //filing here for generating receipt of added product          
        String fileName = "allProducts";
        FileWriter outStream = null;
       try{
              outStream = new FileWriter(fileName,true);
           
             outStream.write("Laptop Brand : "+this.productName + "\n" +
                           "Laptop Model  : "+this.model + "\n" + 
                           "Product Id : "+this.productId + "\n" + 
                           "Laptop Price : "+this.price+"\n"+
                           "Laptop Quantity : "+this.quantity+"\n"+
                           "Processor  : "+this.processor+"\n"+
                            "Operating System : "+this.operatingSystem + "\n"+
                            "Warranty : "+this.warranty + "Year(s) \n"+
                            "RAM  : "+this.RAM+"GB \n"+
                            "Storage : "+this.storage+"GB \n"+
                            "Screen Size : "+this.screenSize+"inch"
                            +"=================================\n");
             outStream.close();
        System.out.println("Book has been added successfully in inventory...");
        }
        catch(FileNotFoundException e){
             System.out.println(e);
        }
        catch(IOException e){
            System.out.println(e);
        }
    }
    @Override
    public void removeProduct(){
        System.out.println("========= Remove Product =========");
        sc.nextLine();
        System.out.print("Enter the Model of Laptop : ");
        String searchModelName = sc.nextLine();
        System.out.print("Enter the Product ID of the Laptop : ");
        int searchProductId = sc.nextInt();
        
        boolean isRemoved = false;
        for(int i = 0; i<laptopList.size(); i++){
            if(searchModelName == null ? laptopList.get(i).getProductName() == null : searchModelName.equals(laptopList.get(i).getProductName())){
                if (searchProductId == laptopList.get(i).getProductId()) {
                    laptopList.remove(this);
                    isRemoved = true;
                }
            }
            
        }
                //invoke printUpdatedArrayInFile in Product class to update data in file

//        if(isRemoved){
//            File fileToDelete = new File("allProducts.txt");
//        if(fileToDelete.delete()){
//        try{
//                    FileWriter outStream = new FileWriter("allProducts.txt");
//
//            for(int i =0;i<laptopList.size();i++){
//            
//            System.out.println("Laptop Brand : "+laptopList.get(i).getProductName() + "\n" +
//                           "Laptop Model  : "+laptopList.get(i).getModel()+ "\n" + 
//                           "Laptop Id : "+laptopList.get(i).getProductId()+ "\n" + 
//                           "Laptop Price : "+laptopList.get(i).getPrice()+"\n"+
//                           "Laptops Quantity : "+laptopList.get(i).getQuantity()+"\n"+
//                           "Processor : "+laptopList.get(i).getProcessor()+"\n"+
//                            "Operating System : "+laptopList.get(i).getOperatingSystem()+ "\n"+
//                            "Warranty : "+laptopList.get(i).getWarranty()+ "\n"+
//                            "RAM : "+laptopList.get(i).getRAM()+"\n"+
//                            "Storage: "+laptopList.get(i).getStorage()+"\n"+
//                            "Screen Size : "+laptopList.get(i).getScreenSize());
//        }
//            
//        }catch(IOException e){
//                    System.out.println("There was an error in opening file....");
//                    }} 
//            System.out.println("Product has been removed from inventory successfully...");
//        }
//        else
//            System.out.println("There was an error removing the product...");
//        
          //Writing new data in file
        
    }
     
    @Override
    public void printDetails(){
        System.out.println("========= Details of Product =========");
        System.out.println("Laptop Brand : "+productName + "\n" +
                           "Laptop Model  : "+model + "\n" + 
                           "Product Id : "+productId + "\n" + 
                           "Laptop Price : "+price+"\n"+
                           "Laptop Quantity : "+quantity+"\n"+
                           "Processor  : "+processor+"\n"+
                            "Operating System : "+operatingSystem + "\n"+
                            "Warranty : "+warranty + "Year(s) \n"+
                            "RAM  : "+RAM+"GB \n"+
                            "Storage : "+storage+"GB \n"+
                            "Screen Size : "+screenSize+"inch");
    }
    
    static public void printAllProducts(){
        System.out.println("========= Details of All Products =========");
        for(int i =0;i<laptopList.size();i++){
            System.out.println("Laptop Brand : "+laptopList.get(i).getProductName() + "\n" +
                           "Laptop Model  : "+laptopList.get(i).getModel()+ "\n" + 
                           "Laptop Product Id : "+laptopList.get(i).getProductId()+ "\n" + 
                           "Laptop Price : "+laptopList.get(i).getPrice()+"\n"+
                           "Laptops Quantity : "+laptopList.get(i).getQuantity()+"\n"+
                           "Laptop Processor : "+laptopList.get(i).getProcessor()+"\n"+
                            "Operating System : "+laptopList.get(i).getOperatingSystem()+ "\n"+
                            "Warranty : "+laptopList.get(i).getWarranty()+ "\n"+
                            "RAM : "+laptopList.get(i).getRAM()+"\n"+
                            "Storage : "+laptopList.get(i).getStorage()+"\n"+
                            "Screen Size : "+laptopList.get(i).getScreenSize());
        }
    }
    
}
