package com.mycompany.e.commercemanagementsystem;

abstract class Login{
    //attributes 
    protected String userName,password;
    
    //behaviours
    abstract protected void login();
    abstract protected void changePassword();
    abstract protected void printUserDetails();
}

