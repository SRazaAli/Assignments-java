package com.mycompany.e.commercemanagementsystem;

import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

public class Book extends Product{
    //attributes
    private String author,publisher,publicationDate,genre,description;
    private int pageCount,ISBN,edition;
    private static ArrayList<Book> bookList = new ArrayList<Book>();
    Scanner sc = new Scanner(System.in);
    
    //constructor 
    public Book() {
    }

    public Book(String productName,int productId,int price,int quantity,String author, String publisher, String publicationDate, String genre, String description, int pageCount, int ISBN, int edition) {
        super(productName,productId,price,quantity);
        this.author = author;
        this.publisher = publisher;
        this.publicationDate = publicationDate;
        this.genre = genre;
        this.description = description;
        this.pageCount = pageCount;
        this.ISBN = ISBN;
        this.edition = edition;
    }
    //getters

    public String getAuthor() {
        return author;
    }

    public String getDescription() {
        return description;
    }

    public int getEdition() {
        return edition;
    }

    public String getGenre() {
        return genre;
    }

    public int getISBN() {
        return ISBN;
    }

    public int getPageCount() {
        return pageCount;
    }

    @Override
    public double getPrice() {
        return price;
    }

    public int getProductId() {
        return productId;
    }

    public String getProductName() {
        return productName;
    }

    public String getPublicationDate() {
        return publicationDate;
    }

    public String getPublisher() {
        return publisher;
    }

    @Override
    public int getQuantity() {
        return quantity;
    }

    public static ArrayList<Book> getBookList() {
        return bookList;
    }
    
    
    //setters

    public void setAuthor(String author) {
        this.author = author;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public void setPublisher(String publisher) {
        this.publisher = publisher;
    }

    public void setPublicationDate(String publicationDate) {
        this.publicationDate = publicationDate;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public void setProductId(int productId) {
        this.productId = productId;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public void setPageCount(int pageCount) {
        this.pageCount = pageCount;
    }

    public void setISBN(int ISBN) {
        this.ISBN = ISBN;
    }

    public void setGenre(String genre) {
        this.genre = genre;
    }

    public void setEdition(int edition) {
        this.edition = edition;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    
    
    //methods
    @Override
    public void addProduct(){
        System.out.println("========= Add Product =========");

        System.out.print("Enter Book Title : ");
        productName = sc.nextLine();
        System.out.print("Enter Author of the book : ");
        author = sc.nextLine();
        System.out.print("Enter Product ID of the Book : ");
        productId = sc.nextInt();
        System.out.print("Enter Price of the Book : ");
        price = sc.nextInt();
        System.out.print("Enter Quantity of Stock : ");
        quantity = sc.nextInt();
        System.out.print("Enter ISBN of the Book : ");
        ISBN = sc.nextInt();
        sc.nextLine();
        System.out.print("Enter Publication Date of the Book : ");
        publicationDate = sc.nextLine();
        System.out.print("Enter Genre of the Book : ");
        genre = sc.nextLine();
        System.out.print("Enter Description of the Book : ");
        description = sc.nextLine();
        System.out.print("Enter Edition of the Book (in numbers) : ");
        edition = sc.nextInt();
        System.out.print("Enter Page Count of the Book : ");
        pageCount = sc.nextInt();
        bookList.add(this);  
    }
    @Override
    public void addProductInFile(){
        //filing here for generating receipt of added product          
        String fileName = "allProducts";
        FileWriter outStream = null;
       try{
              outStream = new FileWriter(fileName,true);
           
             outStream.write("Book Title : "+this.productName + "\n" +
                           "Book Author  : "+this.author + "\n" + 
                           "Book Id : "+this.productId + "\n" + 
                           "Book Price : "+this.price+"\n"+
                           "Books Quantity : "+this.quantity+"\n"+
                           "Book ISBN : "+this.ISBN+"\n"+
                            "Publication Date : "+this.publicationDate + "\n"+
                            "Book Genre : "+this.genre + "\n"+
                            "Book Description : "+this.description+"\n"+
                            "Book Edition : "+this.edition+"\n"+
                            "Book Page Count : "+this.pageCount+"\n"
                            +"=================================\n");
             outStream.close();
        System.out.println("Book has been added successfully in inventory...");
        }
        catch(FileNotFoundException e){
             System.out.println(e);
        }
        catch(IOException e){
            System.out.println(e);
        }
    }


   
    @Override
    public void removeProduct(){
        System.out.println("========= Remove Product =========");
        sc.nextLine();
        System.out.print("Enter the Name of the Book : ");
        String searchProductName = sc.nextLine();
        System.out.print("Enter the Product ID of the Book : ");
        int searchProductId = sc.nextInt();
        
        boolean isRemoved = false;
        for(int i = 0; i<bookList.size(); i++){
            if(searchProductName == null ? bookList.get(i).getProductName() == null : searchProductName.equals(bookList.get(i).getProductName())){
                if (searchProductId == bookList.get(i).getProductId()) {
                    bookList.remove(this);
                    isRemoved = true;
                }
            }
            
        }
        if(isRemoved){          //overriding the updated detais in file
        try{
                    FileWriter outstream = new FileWriter("allProducts.txt");

            for(int i =0;i<bookList.size();i++){
            
            outstream.write("Book Title : "+bookList.get(i).getProductName() + "\n" +
                           "Book Author  : "+bookList.get(i).getAuthor()+ "\n" + 
                           "Book Id : "+bookList.get(i).getProductId()+ "\n" + 
                           "Book Price : "+bookList.get(i).getPrice()+"\n"+
                           "Books Quantity : "+bookList.get(i).getQuantity()+"\n"+
                           "Book ISBN : "+bookList.get(i).getISBN()+"\n"+
                            "Publication Date : "+bookList.get(i).getPublicationDate()+ "\n"+
                            "Book Genre : "+bookList.get(i).getGenre()+ "\n"+
                            "Book Description : "+bookList.get(i).getDescription()+"\n"+
                            "Book Edition : "+bookList.get(i).getEdition()+"\n"+
                            "Book Page Count : "+bookList.get(i).getPageCount());
        }
            
        }catch(IOException e){
                    System.out.println("There was an error in opening file....");
                    }
        
    
            System.out.println("Product has been removed from inventory successfully...");
        }
        else
            System.out.println("There was an error removing the product...");
        
        //Writing new data in file
        
    }
    
    @Override
    public void printDetails(){
        System.out.println("========= Details of Product =========");
        System.out.println("Book Title : "+productName + "\n" +
                           "Book Author  : "+author + "\n" + 
                           "Book Id : "+productId + "\n" + 
                           "Book Price : "+price+"\n"+
                           "Books Quantity : "+quantity+"\n"+
                           "Book ISBN : "+ISBN+"\n"+
                            "Publication Date : "+publicationDate + "\n"+
                            "Book Genre : "+genre + "\n"+
                            "Book Description : "+description+"\n"+
                            "Book Edition : "+edition+"\n"+
                            "Book Page Count : "+pageCount);
    }
    
    static public void printAllProducts(){
        System.out.println("========= Details of All Books =========");
        for(int i =0;i<bookList.size();i++){
            System.out.println("Book Title : "+bookList.get(i).getProductName() + "\n" +
                           "Book Author  : "+bookList.get(i).getAuthor()+ "\n" + 
                           "Book Id : "+bookList.get(i).getProductId()+ "\n" + 
                           "Book Price : "+bookList.get(i).getPrice()+"\n"+
                           "Books Quantity : "+bookList.get(i).getQuantity()+"\n"+
                           "Book ISBN : "+bookList.get(i).getISBN()+"\n"+
                            "Publication Date : "+bookList.get(i).getPublicationDate()+ "\n"+
                            "Book Genre : "+bookList.get(i).getGenre()+ "\n"+
                            "Book Description : "+bookList.get(i).getDescription()+"\n"+
                            "Book Edition : "+bookList.get(i).getEdition()+"\n"+
                            "Book Page Count : "+bookList.get(i).getPageCount());
        }
    }
   
    
}
