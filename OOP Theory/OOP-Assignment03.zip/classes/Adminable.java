package com.mycompany.e.commercemanagementsystem;

interface Adminable {
    
    //for managing orders, viewing inventory, updating customer information
    void viewLoginHistroy();
    void viewInventory();
    void viewOrderHistory();
    void deleteCustomer();    
}
