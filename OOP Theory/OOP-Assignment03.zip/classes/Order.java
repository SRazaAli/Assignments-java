package com.mycompany.e.commercemanagementsystem;

import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

public class Order {
    //attributes
    private int quantity;
     private double totalPrice;
    //aggregrated with Book and Laptop
    Book bookObj;
    Laptop laptopObj;
    Customer customerObj;
    Scanner sc = new Scanner(System.in);
    private ArrayList<Book> orderedBooksList = new ArrayList<Book>();
    private ArrayList<Laptop> orderedLaptopList = new ArrayList<Laptop>();
    
    //getters
    public int getQuantity(){    
        return quantity;
    }

    public double getTotalPrice() {
        return totalPrice;
    }
    //setters

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public void setTotalPrice(double totalPrice) {
        this.totalPrice = totalPrice;
    }
    //constructors

    public Order() {
    }

    public Order(int totalPrice, int quantity, Book bookObj, Laptop laptopObj, Customer customerObj) {
        this.totalPrice = totalPrice;
        this.quantity = quantity;
        this.bookObj = bookObj;
        this.laptopObj = laptopObj;
        this.customerObj = customerObj;
    }
    

    //methods
    public void placeOrder() {
        System.out.println("======================================\n"
                +          "             All Products           "
                +          "\n======================================");

        Book.printAllProducts();
        Laptop.printAllProducts();
        System.out.println("Enter the name of the product you want to buy : ");
        String productName = sc.nextLine();
        System.out.println("Enter the Product ID : ");
        int productId = sc.nextInt();
        
        boolean productExists = false;
        Book orderBook = null;
        //iterating over bookList for checking books
        for(int i = 0;i<Book.getBookList().size();i++){
            if((productName == null ? bookObj.getBookList().get(i).getProductName() == null : productName.equals(bookObj.getBookList().get(i).getProductName())) && productId == bookObj.getBookList().get(i).getProductId()){
                orderBook =  bookObj.getBookList().get(i);
                productExists = true;
                break;
            }
        }
        //iterating over LaptopList for checking laptops
        Laptop orderLaptop = null;
        for(int i = 0;i<Laptop.getLaptopList().size();i++){
            if((productName == null ? laptopObj.getLaptopList().get(i).getProductName() == null : productName.equals(laptopObj.getLaptopList().get(i).getProductName())) && productId == laptopObj.getLaptopList().get(i).getProductId()){
                orderLaptop =  laptopObj.getLaptopList().get(i);
                productExists = true;
                break;
            }
        }
        //print details if product exists
        if(productExists){
            System.out.println("The Product you selected is : ");
            if(orderBook != null){
                orderBook.printDetails();
                calculateTotalPrice(orderBook);
            }
            else if(laptopObj != null){
                orderLaptop.printDetails();
                calculateTotalPrice(orderLaptop);
                
                
            }
            else
                System.out.println("The Product You entered doesn't exist in the inventory...");
        }
    }
    public void calculateTotalPrice(Product product){       //for calculating total price of products

        System.out.println("========= Calculate Total Price =========");

        System.out.println("Enter the Quantity You want to buy : ");
               int purchaseQuantity = sc.nextInt();
               this.setQuantity(purchaseQuantity);
               
               if(product.getQuantity() >= this.getQuantity()){
                  double totalPrice =  purchaseQuantity*product.getPrice();
                   this.setTotalPrice(totalPrice);
                   System.out.println("Your Total Price is : "+this.getTotalPrice());
                   System.out.println("Your Order has been placed. Thank you for Shopping from our store...");
                   //downcasting product to store in arrays
                   if(product instanceof Book){
                       Book bookObj = (Book)product;
                       orderedBooksList.add(bookObj);
                   }
                   else if(product instanceof Laptop){
                       Laptop laptopObj = (Laptop)product;
                       orderedLaptopList.add(laptopObj);
                   }
                   //updating the stock in array
                   product.setQuantity(product.getQuantity() - purchaseQuantity);  
                   //printing the updated array in file................
    }
    }
    public void writeOrderPlaceTimeInFile(Product product){      //for storing the time on which order was placed in a file
        LocalDateTime currentDateTime = LocalDateTime.now();
        
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        String formattedDateTime = currentDateTime.format(formatter);
        
        FileWriter outStream = null;
        try{
              outStream = new FileWriter("orderManager.txt",true); 
             outStream.write("Product Name : "+product.productName+"   Product ID : "+product.productId+"\nTotal Price : "+this.getTotalPrice()
                             +"was added in inventory at "+formattedDateTime+" and will be delivered within one week");
             outStream.close();
        }
        catch(FileNotFoundException e){
             System.out.println(e);
        }
        catch(IOException e){
            System.out.println(e);
    }}
    public void cancelOrder(){
        System.out.println("========= Cancel Order =========");
        System.out.print("Enter the Product Name : ");
        sc.nextLine();
        String cancelOrderName = sc.nextLine();
        System.out.print("Enter the Product ID : ");
        int cancelOrderId = sc.nextInt();
        
        //iterating over arrays to find if the order was placed
        boolean orderExists = false;
        Book bookObj = null;
        for(int i = 0;i<orderedBooksList.size();i++){
            if((cancelOrderName == null ? orderedBooksList.get(i).getProductName() == null : cancelOrderName.equals(orderedBooksList.get(i).getProductName())) && cancelOrderId == orderedBooksList.get(i).getProductId()){
               bookObj = orderedBooksList.get(i);
               
               //updating the stock in original array
               if(bookObj.getProductName() == Book.getBookList().get(i).getProductName() && bookObj.getProductId() == Book.getBookList().get(i).getProductId()){
                Book.getBookList().get(i).setQuantity(Book.getBookList().get(i).getQuantity() + this.getQuantity());     
               }
                orderExists = true;                                                
            }
        }
        Laptop laptopObj = null;
        for(int i = 0;i<orderedLaptopList.size();i++){
            if((cancelOrderName == null ? orderedLaptopList.get(i).getProductName() == null : cancelOrderName.equals(orderedLaptopList.get(i).getProductName())) && cancelOrderId == orderedLaptopList.get(i).getProductId()){
            laptopObj = orderedLaptopList.get(i);
            
            //updating the stock in original array
            if(laptopObj.getProductName() == Laptop.getLaptopList().get(i).getProductName() && laptopObj.getProductId() == Laptop.getLaptopList().get(i).getProductId()){
                Laptop.getLaptopList().get(i).setQuantity(Laptop.getLaptopList().get(i).getQuantity() + this.getQuantity());     
               }    
            
                orderExists = true;
                
            }
        }
        if(orderExists){
         if(bookObj != null){
            orderedBooksList.remove(bookObj);
             System.out.println("Order Cancellation was successful....");
         }
         else if (laptopObj != null){
             orderedLaptopList.remove(laptopObj);
         }          
        }
        else{
            System.out.println("Such Order does not exist....");
        }
    }
     
    
    public void writeOrderCancelTimeInFile(Product product){            //for storing the time on which order was canceled in a file
        LocalDateTime currentDateTime = LocalDateTime.now();
        
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        String formattedDateTime = currentDateTime.format(formatter);
        
        FileWriter outStream = null;
        try{
              outStream = new FileWriter("orderManager.txt",true); 
             outStream.write("Product Name : "+product.productName+"   Product ID : "+product.productId+"\nTotal Price : "+this.getTotalPrice()
                             +"was added in inventory at "+formattedDateTime+" and will be delivered within one week");
             outStream.close();
        }
        catch(FileNotFoundException e){
             System.out.println(e);
        }
        catch(IOException e){
            System.out.println(e);
    }
    }
    public void generateInvoice(Product product,Customer customer){
        Random random = new Random();
        int invoiceNumber = random.nextInt(1000) + 1;
        System.out.println("======================================\n"
                +          "             Invoice           "
                +          "\n======================================");
        System.out.println("Customer Name : " + customer.getUserName()+"\n"+
                           "Mobile no : "+customer.getMobileNo()+ "\n"+
                           "Email : "+customer.getEmail()+"\n"+
                           "Shipping Address : "+customer.getShippingAddress()+"\n"+
                           "Post Code : "+customer.getPostCode()+"\n"+
                           "Invoice number : "+invoiceNumber);
        System.out.println("=====================================");
        System.out.println("Product Name : "+product.productName +"\n"+
                           "Product Id : "+product.productId+"\n"+
                           "Per unit price : "+product.price +"\n"+
                           "Quantity : "+this.getQuantity()+"\n"+
                           "Total Price : "+this.getTotalPrice());
         System.out.println("=====================================");
    }
}
