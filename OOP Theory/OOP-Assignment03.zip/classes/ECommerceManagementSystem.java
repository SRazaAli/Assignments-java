package com.mycompany.e.commercemanagementsystem;

public class ECommerceManagementSystem {

    public static void main(String[] args) {
        
     
        AdminLogin admin = new AdminLogin();
        admin.login();
       AdminControls controller1 = new AdminControls();
       controller1.viewInventory();
       controller1.viewOrderHistory();
      
        
        
//       // obj of Customer class  
//       AdminLogin admin = new AdminLogin();
//       
//       //two obj of product class
//       Book book1 = new Book();
//       Laptop laptop1 = new Laptop();
//       book1.addProduct();
//       book1.addProductInFile();
//       laptop1.addProduct();
//       laptop1.addProductInFile();
//       
//       obj of customer
      
//       
//       //obj of Order class
//       Order order1 = new Order();
//       order1.placeOrder();
//       order1.writeOrderPlaceTimeInFile(book1);
//       order1.getTotalPrice();
//       order1.generateInvoice(book1, customer1);
  }
    
}
